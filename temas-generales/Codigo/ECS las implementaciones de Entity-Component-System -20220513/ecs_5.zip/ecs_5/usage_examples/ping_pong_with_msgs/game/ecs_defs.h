// This file is part of the course TPV2@UCM - Samir Genaim

#pragma once

// Components list - the struct names should coincide with those of
// the components
//
struct Transform;
struct Image;
struct RectangleViewer;
struct PaddleCtrl;
struct GameState;

#define _CMPS_LIST_ \
		 Transform,\
		 Image,\
		 RectangleViewer,\
		 PaddleCtrl,\
		 GameState

// Systems list - the struct names should coincide with those of
// the components
//
class BallSystem;
class PaddlesSystem;
class GameCtrlSystem;
class RenderSystem;
class CollisionsSystem;

#define _SYS_LIST_ \
		 BallSystem,\
		 PaddlesSystem,\
		 GameCtrlSystem,\
		 RenderSystem,\
		 CollisionsSystem

// Groups list - the struct names can be anything, they are simply used as
// identifier, these types are no used for variable declaration
//
struct _grp_PADDLES;
#define _GRPS_LIST_ \
	_grp_PADDLES

// Handlers list - the struct names can be anything, they are simply used as
// identifier, these types are no used for variable declaration
//
struct _hdlr_BALL;
#define _HDLRS_LIST_ \
	_hdlr_BALL

