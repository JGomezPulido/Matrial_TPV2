# Entity-Component-System v5


The one that uses template meta-programming to calculate the numeric identifiers of the components.

 



