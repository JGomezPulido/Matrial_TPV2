// This file is part of the course TPV2@UCM - Samir Genaim

// DO NOT USE/MODIFY THIS FILE, IT IS JUST AN EXAMPLE OF HOW YOUR
// game/ecs_defs.h SHOULD LOOK LIKE
//
// Note that the backslash \ after each line below is very important
// when using #define, if you remove it then put all at the same
// line of #define
//

#pragma once

// Components list - the struct names should coincide with those of
// the components
//
struct Transform;
struct Image;
struct RectangleViewer;
struct PaddleCtrl;
struct GameState;

#define _CMPS_LIST_ \
		 Transform,\
		 Image,\
		 RectangleViewer,\
		 PaddleCtrl,\
		 GameState

// Systems list - the struct names should coincide with those of
// the components
//
class BallSystem;
class PaddlesSystem;
class GameCtrlSystem;
class RenderSystem;
class CollisionsSystem;

#define _SYS_LIST_ \
		 BallSystem,\
		 PaddlesSystem,\
		 GameCtrlSystem,\
		 RenderSystem,\
		 CollisionsSystem

// Groups list - the struct names can be anything, they are simply used as
// identifier, these types are no used for variable declaration.
//
// *** You should not use _grp_GENERAL, it is reserved
//
struct _grp_PADDLES;
#define _GRPS_LIST_ \
	_grp_PADDLES

// Handlers list - the struct names can be anything, they are simply used as
// identifier, these types are no used for variable declaration
//
struct _hdlr_BALL;
#define _HDLRS_LIST_ \
	_hdlr_BALL

