// This file is part of the course TPV2@UCM - Samir Genaim

#pragma once

#include "Transform.h"
#include "RectangleViewer.h"
#include "PaddleCtrl.h"
#include "Image.h"
#include "GameState.h"




