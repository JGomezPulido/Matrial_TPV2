// This file is part of the course TPV2@UCM - Samir Genaim

#include "Manager.h"

#include "../components/all_components.h"

namespace ecs {

Manager::Manager() :
		entsPool_(), //
		usedEnts_(), //
		lastUsedEntity_(), //
		cmpsPool_(), //
		hdlrs_(), //
		entsByGroup_(), //
		sys_(), //
		msgs_(), //
		msgs_aux_() //
{

	// for each group we reserve space for 100 entities,
	// just to avoid resizing
	//
	for (auto &groupEntities : entsByGroup_) {
		groupEntities.reserve(100);
	}

	// allocate enough space for the messages queue,
	// just to avoid resizing
	//
	msgs_.reserve(100);
	msgs_aux_.reserve(100);

	//
	PoolHelper<CmpsList>::init(cmpsPool_);
}

Manager::~Manager() {

	// delete systems
	//
	for (auto i = 0u; i < maxSystemId; i++)
		if (sys_[i] != nullptr)
			delete sys_[i];

	// delete all entities -- not really needed
	//
	for (auto &ents : entsByGroup_) {
		for (auto e : ents)
			freeEntity(e);
	}

	// delete components pool
	//
	PoolHelper<CmpsList>::free(cmpsPool_);

}

void Manager::refresh() {

	// remove dead entities from the groups lists, and also those
	// do not belong to the group anymore
	for (ecs::grpId_type gId = 0; gId < ecs::maxGroupId; gId++) {
		auto &groupEntities = entsByGroup_[gId];
		groupEntities.erase(
				std::remove_if(groupEntities.begin(), groupEntities.end(),
						[this](entity_t eIdx) {
							if (isAlive(eIdx)) {
								return false;
							} else {
								freeEntity(eIdx);
								return true;
							}
						}), groupEntities.end());
	}

}

} // end of namespace
