// This file is part of the course TPV2@UCM - Samir Genaim

#pragma once

#include <iostream>
#include <cassert>
#include <cstdint>
#include <limits>
#include <tuple>

#include "mpl.h"

// definition for general group
//
struct _grp_GENERAL;

// You should define a file ../game/ecs_defs.h with the list of your
// components, groups, and handlers. See ecs_defs_example.h for an
// example file
//
#if __has_include("../game/ecs_defs.h")
#include "../game/ecs_defs.h"
#endif

#ifndef _CMPS_LIST_
#define _ext_CMPS_LIST_
#else
#define _ext_CMPS_LIST_ _CMPS_LIST_
#endif

#ifndef _GRPS_LIST_
#define _ext_GRPS_LIST_ _grp_GENERAL
#else
#define _ext_GRPS_LIST_ _grp_GENERAL,_GRPS_LIST_
#endif

#ifndef _SYS_LIST_
#define _ext_SYS_LIST_
#else
#define _ext_SYS_LIST_ _SYS_LIST_
#endif

#ifndef _HDLRS_LIST_
#define _ext_HDLRS_LIST_
#else
#define _ext_HDLRS_LIST_ _HDLRS_LIST_
#endif

#ifndef _MAX_NUM_ENTITIES_
#define _ext_MAX_NUM_ENTITIES_ 100
#else
#define _ext_MAX_NUM_ENTITIES_ _MAX_NUM_ENTITIES_
#endif

static_assert( _ext_MAX_NUM_ENTITIES_ > 0);

namespace ecs {

struct Component;
class Manager;
class System;

// TypeLists for components, systems, groups and handlers
//
using CmpsList = mpl::TypeList<_ext_CMPS_LIST_>;
using SysList = mpl::TypeList<_ext_SYS_LIST_>;
using GrpsList = mpl::TypeList<_ext_GRPS_LIST_>;
using HdlrsList = mpl::TypeList<_ext_HDLRS_LIST_>;

// automatically choose a type large enough to hold corresponding IDs
//
using cmpId_type = mpl::numeric_type<CmpsList::size>::type;
using grpId_type = mpl::numeric_type<GrpsList::size>::type;
using hdlrId_type = mpl::numeric_type<HdlrsList::size>::type;
using sysId_type = mpl::numeric_type<SysList::size>::type;
using entId_type = mpl::numeric_type<_ext_MAX_NUM_ENTITIES_>::type;

// entity type
using entity_t = entId_type;

template<typename T>
constexpr cmpId_type cmpId = mpl::IndexOf<T, CmpsList>();

template<typename T>
constexpr sysId_type sysId = mpl::IndexOf<T, SysList>();

template<typename T>
constexpr grpId_type grpId = mpl::IndexOf<T, GrpsList>();

template<typename T>
constexpr hdlrId_type hdlrId = mpl::IndexOf<T, HdlrsList>();

constexpr cmpId_type maxComponentId = CmpsList::size;
constexpr grpId_type maxGroupId = GrpsList::size;
constexpr hdlrId_type maxHandlerId = HdlrsList::size;
constexpr sysId_type maxSystemId = SysList::size;
constexpr entId_type maxNumberEntities = _ext_MAX_NUM_ENTITIES_;

template<typename >
struct PoolHelper;

template<typename ...Ts>
struct PoolHelper<mpl::TypeList<Ts...>> {
	using tuple_t = std::tuple<Ts...>;
	using tuple_arr_t = std::tuple<Ts[maxNumberEntities]...>;
	using tuple_parr_t = std::tuple<Ts*...>;

	static void init(tuple_parr_t &t) {
		// para un T de Ts
	( (std::get<cmpId<Ts>>(t) = new Ts[maxNumberEntities]), ...);
}

static void free(tuple_parr_t &t) {
	// para un T de Ts
( delete [] std::get<cmpId<Ts>>(t), ...);
}
};

using tuple_cmps_t = PoolHelper<CmpsList>::tuple_t;
using tuple_arr_cmps_t = PoolHelper<CmpsList>::tuple_arr_t;
using tuple_parr_cmps_t = PoolHelper<CmpsList>::tuple_parr_t;

} // end of namespace

