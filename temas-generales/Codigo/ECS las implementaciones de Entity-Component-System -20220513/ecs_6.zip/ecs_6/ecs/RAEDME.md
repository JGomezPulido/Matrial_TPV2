# Entity-Component-System v4


It is like v3, but the IDs for components and systems are generated automatically, at runtime, using the class IDS.

Whle IDs are generated automatically, you still have to provide the number of components and system in game/ecs_defs.h since it has to be known statically (see ecs_defs_example.h)
 



