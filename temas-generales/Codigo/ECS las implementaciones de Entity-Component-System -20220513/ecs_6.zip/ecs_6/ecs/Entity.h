// This file is part of the course TPV2@UCM - Samir Genaim

#pragma once
#include <array>
#include <bitset>
#include <cassert>
#include <vector>

#include "Component.h"
#include "ecs.h"

namespace ecs {

/*
 * A struct that represents a collection of components. It just keep
 * a bitset to mark if it has the corresponding component or not. It
 * also keeps the group ID, and boolean indicating if it is alive or
 * dead.
 *
 */
struct Entity {
	Entity() :
			cmps_(), //
			alive_(),  //
			gId_(0) //
	{
	}

	virtual ~Entity() {
	}

	std::bitset<maxComponentId> cmps_;
	bool alive_;
	ecs::grpId_type gId_;
};

} // end of name space
