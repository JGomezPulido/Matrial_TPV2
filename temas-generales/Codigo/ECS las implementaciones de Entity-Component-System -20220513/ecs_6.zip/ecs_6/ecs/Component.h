// This file is part of the course TPV2@UCM - Samir Genaim

#pragma once

#include "ecs.h"

namespace ecs {

/*
 * Structs that inherit from Component must define a field
 *
 *   	constexpr static ecs::cmpId_type id = value;
 *
 * where value is from the enum ecs::cmpId (see ecs.h). This
 * how we assign numeric identifiers to components (so we can
 * easily put them in an array). The list of possible identifiers
 * is defined as an enum in ecs.h
 *
 * We use a struct to emphasise that it is actually a data structure
 * in ECS, and also to have default visibility as public. In principle,
 * we don't need the methods update/render because one of the reasons to
 * use system is to avoid calling these virtual methods. Nevertheless, we
 * leave them to allow using this version of ecs without systems as well.
 *
 */
struct Component {
public:
	Component() {
	}

	// Destroys the component.
	// Careful! ent_ and mngr_ should not be destroyed
	//
	virtual ~Component() {
	}

	// We assume that initComponent will be called when adding a
	// component to an entity, immediately after setContext.
	//
	virtual void initComponent() {
	}

protected:
	// as mentions above, when using systems these fields are not
	// really needed, but we keep them for now from the same reason that
	// we keep update/render
	//
};

} // end of namespace
