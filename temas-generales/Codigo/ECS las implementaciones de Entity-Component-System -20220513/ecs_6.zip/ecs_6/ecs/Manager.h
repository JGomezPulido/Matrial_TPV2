// This file is part of the course TPV2@UCM - Samir Genaim

#pragma once
#include <iostream>
#include <vector>
#include <array>
#include <bitset>
#include <cassert>
#include <tuple>

#include "Component.h"
#include "ecs.h"
#include "messages.h"
#include "Entity.h"
#include "System.h"




namespace ecs {

/*
 * A class for managing the list of entities, groups, etc.
 *
 * Internally, entities are represented by the struct Entity, and from outside
 * they are just indices of corresponding object in the pool entsPool_
 *
 */
class Manager {

public:
	Manager();
	virtual ~Manager();

	// Adding an entity simply creates an instance of Entity, using the pool in the case,
	// adds it to the list of the given group and returns the Id to the caller.
	//
	template<typename T = _grp_GENERAL>
	inline entity_t addEntity() {

		constexpr auto gId = grpId<T>;

		// allocate
		auto eIdx = allocEntity();
		auto e = getEntityByIdx(eIdx);

		// initialize
		e->cmps_.reset();
		e->gId_ = gId;
		e->alive_ = true;

		// add it to the corresponding list
		entsByGroup_[gId].push_back(eIdx);

		// return it to the caller (just the index)
		return eIdx;
	}

	// Setting the state of entity 'eIdx' (alive or dead)
	//
	inline void setAlive(entity_t eIdx, bool alive) {
		auto e = getEntityByIdx(eIdx);
		e->alive_ = alive;
	}

	// Returns the state of entity 'eIdx' (alive o dead)
	//
	inline bool isAlive(entity_t eIdx) {
		auto e = getEntityByIdx(eIdx);
		return e->alive_;
	}

	// Adds a component to the entity 'e'. It receives the type
	// T (to be created). It does not receive the list of arguments
	// anymore since the objects are already created (in the pool), so
	// initialization should be done outside
	//
	template<typename T>
	inline T* addComponent(entity_t eIdx) {

		constexpr cmpId_type cId = ecs::cmpId<T>;
		assert(cId < maxComponentId);

		// create and initialize the new component
		//
		T *c = getComponentFromPool<T>(eIdx);
		c->initComponent();

		// mark entity 'eIdx' as one that has component T
		auto e = getEntityByIdx(eIdx);
		e->cmps_[cId] = true;

		// return the component to the user so it can be initialized if needed
		return c;
	}

	// Removes the component T of entity 'eIdx'.
	//
	template<typename T>
	inline void removeComponent(entity_t eIdx) {
		constexpr cmpId_type cId = ecs::cmpId<T>;
		assert(cId < maxComponentId);
		auto e = getEntityByIdx(eIdx);
		e->cmps_[cId] = false;
	}

	// Returns a pointer to the component T of entity 'eIdx'
	//
	template<typename T>
	inline T* getComponent(entity_t eIdx) {
		return getComponentFromPool<T>(eIdx);
	}

	// Returns true if entity 'eIdx' has a component  T
	//
	template<typename T>
	inline bool hasComponent(entity_t eIdx) {
		constexpr cmpId_type cId = ecs::cmpId<T>;
		assert(cId < maxComponentId);
		auto e = getEntityByIdx(eIdx);
		return e->cmps_[cId];
	}

	// returns the group of entity 'eIdx'
	//
	inline grpId_type groupId(entity_t eIdx) {
		return getEntityByIdx(eIdx)->gId_;
	}

	// returns the vector of all entities of the group G
	//
	template<typename G = _grp_GENERAL>
	inline const auto& getEntities() {
		constexpr auto gId = grpId<G>;
		return entsByGroup_[gId];;
	}

	// associates entity 'eIdx' to the handler 'H'
	//
	template<typename H>
	inline void setHandler(entity_t eIdx) {
		constexpr auto hId = hdlrId<H>;
		assert(hId < maxHandlerId);
		hdlrs_[hId] = eIdx;
	}

	// returns the entity associated to the handler 'H'
	//
	template<typename H>
	inline entity_t getHandler() {
		constexpr auto hId = hdlrId<H>;
		assert(hId < maxHandlerId);
		return hdlrs_[hId];
	}

	// Adds a System to the manager. It receives the type
	// T of the system (to be created), and the list of
	// arguments (if any) to be passed to the system.
	//
	template<typename T, typename ...Ts>
	inline T* addSystem(Ts &&... args) {

		constexpr sysId_type sId = ecs::sysId<T>;
		assert(sId < maxSystemId);

		removeSystem<T>();

		// create, initialize and install the new component
		//
		System *s = new T(std::forward<Ts>(args)...);
		s->setContext(this);
		s->initSystem();
		sys_[sId] = s;

		// return it to the user so it can be initialized if needed
		return static_cast<T*>(s);
	}

	// Removes the system T
	//
	template<typename T>
	inline void removeSystem() {

		constexpr sysId_type sId = ecs::sysId<T>;
		assert(sId < maxSystemId);

		if (sys_[sId] != nullptr) {

			// destroy it
			//
			delete sys_[sId];

			// remove the pointer
			//
			sys_[sId] = nullptr;
		}
	}

	// Returns a pointer to the system 'T'.
	//
	template<typename T>
	inline T* getSystem() {

		constexpr sysId_type sId = ecs::sysId<T>; //T::id;
		assert(sId < maxSystemId);

		return static_cast<T*>(sys_[sId]);
	}

	// Send a message 'm' to all systems. The 'delay' indicates if it should
	// be sent immediately or later when calling flushMessage
	//
	inline void send(const Message &m, bool delay = false) {
		if (!delay) {
			for (System *s : sys_) {
				if (s != nullptr)
					s->recieve(m);
			}
		} else {
			// will make a copy of m, we could use std::move to move it
			// but then we will have to remove const from above
			msgs_.emplace_back(m);
		}
	}

	// This method should be called in the main loop to send queued
	// messages, i.e., those were sent using send(m,true)
	//
	inline void flushMessages() {

		// we traverse until msgs_.size(), so if new message
		// we added we don't send them now. If you wish to send
		// them as will you should write this loop in a different way
		// and maybe using std::list would be better.
		//
		auto size = msgs_.size();
		for (auto i = 0u; i < size; i++) {
			auto &m = msgs_[i];
			for (System *s : sys_) {
				if (s != nullptr)
					s->recieve(m);
			}
		}

		// delete all message that we have sent. This might be expensive
		// since it has to shift all remaining elements to the left. A better
		// solution would be to keep two vectors 'v1' and 'v2', when sending a
		// message we always add it to 'v1' and in flush we swap them and send
		// all messages in v2. After flush we simply clear v2
		//
		msgs_.erase(msgs_.begin(), msgs_.begin() + size);
	}

	// THIS IS THE VERSION THAT SWAP QUEUES, IF YOU WANT TO USE IT
	//
	// this method should be called in the main loop to send queued
	// messages, i.e., those were sent using send(m,true)
	//
	inline void flushMessagesWithSwap() {
		std::swap(msgs_, msgs_aux_);
		for (auto &m : msgs_aux_) {
			for (System *s : sys_) {
				if (s != nullptr)
					s->recieve(m);
			}
		}

		msgs_aux_.clear();
	}

	void refresh();

private:

	// Entities pool
	//
	std::array<Entity, maxNumberEntities> entsPool_;
	std::bitset<maxNumberEntities> usedEnts_;
	std::size_t lastUsedEntity_;

	inline entity_t allocEntity() {
		auto aux = lastUsedEntity_ + 1 % maxNumberEntities;
		while (usedEnts_[aux] && aux != lastUsedEntity_)
			aux = aux + 1 % maxNumberEntities;

		assert(!usedEnts_[aux]);

		usedEnts_[aux] = true;
		lastUsedEntity_ = aux;
		return aux;
	}

	inline Entity* getEntityByIdx(entity_t idx) {
		assert(idx < maxNumberEntities);
		return &entsPool_[idx];
	}

	inline void freeEntity(entity_t eIdx) {
		assert(usedEnts_[eIdx]);
		usedEnts_[eIdx] = false;
	}

	// Components pool
	//
	tuple_parr_cmps_t cmpsPool_;

	template<typename T>
	inline T* getComponentFromPool(entity_t eIdx) {
		constexpr auto cId = cmpId<T>;
		auto pool = std::get<cId>(cmpsPool_);
		return pool + eIdx;
	}

	// other fields
	//
	std::array<entity_t, maxHandlerId> hdlrs_;
	std::array<std::vector<entity_t>, maxGroupId> entsByGroup_;
	std::array<System*, maxSystemId> sys_;

	std::vector<Message> msgs_;
	std::vector<Message> msgs_aux_;

};

} // end of namespace
