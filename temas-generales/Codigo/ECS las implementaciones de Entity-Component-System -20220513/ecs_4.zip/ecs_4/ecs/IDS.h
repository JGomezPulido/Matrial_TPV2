// This file is part of the course TPV2@UCM - Samir Genaim

#pragma once

#include "ecs.h"

namespace ecs {
class IDS {
private:
	static cmpId_type gloablCmpId;
	static cmpId_type gloablSysId;

	IDS() {
	}

public:
	virtual ~IDS() {
	}

	template<typename T>
	static cmpId_type getCmpId() {
		static cmpId_type cmpId = gloablCmpId++;
		assert(cmpId < maxComponentId);
		return cmpId;
	}

	template<typename T>
	static sysId_type getSysId() {
		static sysId_type sysId = gloablSysId++;
		assert(sysId < maxSystemId);
		return sysId;
	}

};

}
