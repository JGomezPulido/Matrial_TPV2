// This file is part of the course TPV2@UCM - Samir Genaim

#include "IDS.h"

namespace ecs {
cmpId_type IDS::gloablCmpId = 0;
cmpId_type IDS::gloablSysId = 0;
}
